# Arbitrage & Promo Hunter Dashboard

Live sports arbitrage scanner with step-by-step bet instructions across all major US sportsbooks.

## Deploy to Vercel (free, 5 minutes)

### Step 1 — Upload to GitHub
1. Go to https://github.com and sign in (or create a free account)
2. Click the **+** icon → **New repository**
3. Name it `arb-dashboard`, set to **Private**, click **Create repository**
4. Click **uploading an existing file**
5. Upload ALL files keeping the folder structure:
   - `api/odds.js`
   - `public/index.html`
   - `vercel.json`
6. Click **Commit changes**

### Step 2 — Deploy on Vercel
1. Go to https://vercel.com and sign in with GitHub
2. Click **Add New Project**
3. Find and select your `arb-dashboard` repository
4. Click **Deploy** (no settings need to change)
5. Wait ~30 seconds — Vercel gives you a live URL like `https://arb-dashboard-xyz.vercel.app`

### Step 3 — Use the dashboard
1. Open your Vercel URL in any browser
2. Click the **Setup** tab
3. Paste your Odds API key (get free key at https://the-odds-api.com)
4. Click **Test** to confirm it works
5. Go to **Arbitrage Scanner** and click **Scan now**

## Features
- Live odds from FanDuel, DraftKings, BetMGM, Caesars, PointsBet, BetRivers, ESPN Bet + more
- Auto-detects guaranteed profit opportunities across sportsbooks
- Step-by-step instructions: which app, how much to bet, exact odds
- Free bet & deposit match converter
- Sign-up promo tracker with expected value estimates
- Adjustable bankroll — all bet sizes auto-calculate
